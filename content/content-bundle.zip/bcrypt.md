# bcrypt
- bcrypt is a [[Password Hashing]] function
- it is adaptive. calculation time depends on provided `cost`
- Based on [[Blowfish Cipher]]
- Input: password, numeric cost, salt
- Output
```
$2a$12$R9h/cIPz0gi.URNNX3kh2OPST9/PgBkqquzi.Ss7KIUgO2t0jWMUW
\__/\/ \____________________/\_____________________________/
Alg Cost      Salt                        Hash
```